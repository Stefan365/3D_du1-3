package DU3;

import java.net.MalformedURLException;
import java.rmi.AccessException;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.rmi.server.UnicastRemoteObject;
import java.util.Iterator;

public class Serverb extends UnicastRemoteObject implements Rozposli {

    /**
     * lokalne prijatie mennej sluzby.
     */
    private Registry reg_s;
    
    /**
     * instancia rozhrania Zobraz, pomocou kt. komunikuje s klientom.
     */
    private Zobraz service_cl;

    //Konstruktor:
    public Serverb() throws RemoteException {
        super();
    }

    //1.
    /**
     * Ma za ulohu vytvorit napojenie na mennu sluzbu, ktora bude odosielat poziadavky klientom.
     *
     * @param menoCl meno daneho klienta(instancie) pod ktorym je zaregistrovany na mennej sluzbe.
     */
    public void initServToClient(String menoCl) throws RemoteException, MalformedURLException, NotBoundException {
        //musi byt napojeny na ten isty menny server ako chat miestnosti.
        reg_s = LocateRegistry.getRegistry(Allb.IP, Allb.cisloClPortu);
        service_cl = (Zobraz) reg_s.lookup(menoCl); // vrací objekt Remote - musím pøety                       
    }

    @Override
    public void rozposli(String sprava, int kam) throws RemoteException, AccessException {

        Iterator itr = Allb.zoz_klientov.iterator(); //chcem vybrat cisla miestnosti.

        Clientb cl;
        
        while (itr.hasNext()) {
            cl = (Clientb) itr.next();
            if (cl.room_id == kam) {
                try {
                    initServToClient(cl.meno_klienta_id);
                    //pozn.: vysiela aj do zavrenych okien, ale to neva.
                    service_cl.zobraz(sprava);
                } catch (MalformedURLException ex) {
                    System.out.println("MalformedURLException, rozposli 1.");
                } catch (NotBoundException ex) {
                    System.out.println("NotBoundException, rozposli 2.");
                }
            }
        }
    }
}
