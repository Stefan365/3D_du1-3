/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package DU3;

import java.rmi.Remote;
import java.rmi.RemoteException;

/**
 *
 * @author User
 */
public interface Rozposli extends Remote {
    
        //pre server:
        public void rozposli(String sprava, int kam) throws RemoteException;
        
}
