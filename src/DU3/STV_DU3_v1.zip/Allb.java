/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package DU3;

import java.awt.BorderLayout;
import java.net.MalformedURLException;
import java.rmi.Naming;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JFrame;

/**
 *
 * @author Stefan Veres
 */
public class Allb {

    /**
     * menna sluzba pre vsetky vzdialene objekty.
     */   
    public static Registry reg_A;// = LocateRegistry.createRegistry(1099);
    
    /**
     * zoznam mien jednotlivych chatovacich miestnosti. Len pre info, 
     * inak sa to v tomto prog. nevyuzije.
     */
    public static List<String> zoz_miestnosti = new ArrayList();
    
    /**
     * zoznam vytvorenych Clientb instancii. 
     * tu sa budu ukladat klientske servisy (tj. dotazovat sa budu zo servera.)
     * ktore sa prihlasia na RMI objekty jednotlivych klientov.
     */
    public static List<Clientb> zoz_klientov = new ArrayList();
    
    /**
     * pocet vytvorenych klientov. kvoli prideleniu jednoznacneho mena.
     */
    public static int pocet_klientov = 0;
    
    /**
     * IP adresa a cislo portu na ktorych bezi menny server.
     */
    public static String IP;// = "localhost";
    public static int cisloClPortu;// = 1099;

    /**
     * Konstruktor.
     */
    public Allb() {
        super();
    }
    
    //Hlavna:
    public static void main(String[] args) throws RemoteException, MalformedURLException, NotBoundException {
        Allb all = new Allb();
        all.initServ("localhost", 1099, 3);

        System.out.println("Skoncil som inicializaciu Chat miestnosti");
        //1.klient:
        Clientb cl = new Clientb();
        all.runClient(cl);
        //2.klient:
        cl = new Clientb();
        all.runClient(cl);
        //3.klient:
        cl = new Clientb();
        all.runClient(cl);
        
        System.out.println("Skoncil som zadavanie klientov");
        while (true);

    }
    
    //1.
    /**
     * Ma za ulohu vytvorit mennu sluzbu, ktora bude osluhovat vs. ucastnikov.
     *
     * @param IP IP adresa kde ma byt spusteny Name server.
     * @param port cislo portu.
     * @param pocetM pocet chatovacich miestnosti
     */
    public void initServ(String IP, int port, int pocetM) throws RemoteException, MalformedURLException {
        Allb.IP = IP;
        Allb.cisloClPortu = port;
        
        //toto staci vytvorit len raz, a bude to platit pre vsetky vlakna.:
        reg_A = LocateRegistry.createRegistry(port);
        this.nakrmZoznamMiestnosti(pocetM);
    }
    
    //2.
    /**
     * Vytvori a zaregistruje chatovacie miestnosti na mennom serveri.
     *
     * @param pocetM pocet chatovacich miestnosti
     */
    private void nakrmZoznamMiestnosti(int pocetM) throws RemoteException {
        String url;
        //String pol_url = "rmi://localhost:1099/";
        String pol_url = "rmi://" + Allb.IP + ":" + Allb.cisloClPortu + "/";
        
        for (int i = 0; i < pocetM; i++) {
            url = pol_url + "M" + i;
            
            //toto je len pre info, inak sa to nevyuzije.
            zoz_miestnosti.add("M" + i);
            
            try {
                //registracia danych miestnosti: 
                Naming.rebind(url, new Serverb());
            } catch (MalformedURLException ex) {
                System.out.println("nepodarilo sa zaregistrovat miestnost c1.:" + i);
            }
        }
    }

    //3.
    /**
     * Omasli vytvoreneho klienta Clientb.
     *
     * @param client client.
     *
     */
    public void runClient(Clientb client) throws RemoteException {

        JFrame frame = new JFrame(client.getMeno());
        frame.setLayout(new BorderLayout());

        frame.add(client);

        frame.setSize(300, 460);
        //frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);

    }
}
