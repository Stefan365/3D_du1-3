/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package DU2;

import java.awt.BorderLayout;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import javax.swing.JFrame;
import javax.swing.JOptionPane;


/**
 *
 * @author Stefan Veres
 */
public class Alla {

    /**
     * zoznam vnutornych tied pre multikastove vysielanie. tieto Predstavuje
     * jednotlive roomy
     */
    public static List<Multicat_Servera.ServisS_send> zoz_SSS = new ArrayList();

    /**
     * univerzalny pool pre vsetky vlakna.
     */
    public static ExecutorService SPRAVCE_U = Executors.newCachedThreadPool();

    public static void main(String[] args) {
        Alla all = new Alla();

        all.runServer();
        all.runClient();
        try {
            Thread.sleep(1200);
        } catch (InterruptedException ex) {
            System.out.println("dosralo sa to");
        }
        //tu si pomocou runClient pridajte tolko klientov, kolko potrebujete.
        all.runClient();
        //all.runClient();
        //all.runClient();
        //all.runClient();
    }

    //M.1.
    /**
     * Spusti vlakno klienta.
     */
    public void runClient() {
        TCPClienta client = new TCPClienta();
        //System.out.println("inst_counter:" + inst_counter);

        JFrame frame = new JFrame(client.getMeno());
        //frame.setLayout(new GridLayout(2,1));
        frame.setLayout(new BorderLayout());

        frame.add(client);//.add(client);
        //frame.add(new JLabel());
        frame.setSize(300, 460);
        //frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);

        SPRAVCE_U.execute(client);
    }

    //M.2.
    /**
     * Spusti vlakno serveru.
     */
    public void runServer() {
        Multicat_Servera karol = new Multicat_Servera();
        SPRAVCE_U.execute((Runnable) karol);

    }


    //M.1.
    /**
     * Na externy poziadavok ziska zoz_SSS.add potreben udaje.
     *
     * @param r_i cislo chatovacej miestnosti
     * @return zoznam potrebnych udajov
     */
    public static Poma getRoomKeys(int r_i) {

        if ((r_i > (zoz_SSS.size() - 1)) || (r_i < 0)) {
            System.out.println("Multicat_Server.zoz_SSS.size():" + zoz_SSS.size());
            JOptionPane.showMessageDialog(null, "Zadal si nespravne cislo Roomu");
            return new Poma("", 0, 0);
        }
        //vrati zoznam Poma s naplnenymi udajmi.
        return zoz_SSS.get(r_i).getMA_CP();
    }
}
