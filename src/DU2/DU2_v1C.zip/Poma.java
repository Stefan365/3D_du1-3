/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package DU2;

/**
 *
 * @author User
 */
public class Poma {
    private int cisloClPortu; //cislo klientskeho portu
    private String multicastAddress; //multicastova adresa
    private int room_id;
    
    public Poma(String mA, int cP, int rId){
        super();
        this.multicastAddress = mA;
        this.cisloClPortu = cP;
        this.room_id = rId;
    }
    
    public String getMA(){
        return this.multicastAddress;
    }
    
    public int getCP(){
        return this.cisloClPortu;
    }
    
    public int getRoomID(){
        return this.room_id;
    }
}
